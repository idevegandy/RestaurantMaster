import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Start the application
createRoot(document.getElementById("root")!).render(<App />);
