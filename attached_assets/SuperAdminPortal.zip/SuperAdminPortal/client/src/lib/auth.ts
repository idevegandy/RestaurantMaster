import React, { createContext, useContext, useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { apiRequest } from './queryClient';

type UserRole = 'super_admin' | 'restaurant_admin';

interface User {
  id: number;
  username: string;
  role: UserRole;
  restaurantId?: number;
}

interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: (username: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [, setLocation] = useLocation();

  // Check if user is already logged in
  useEffect(() => {
    const checkAuth = async () => {
      try {
        console.log('Checking authentication status...');
        const response = await fetch('/api/auth/me', {
          credentials: 'include'
        });
        
        if (response.ok) {
          const data = await response.json();
          console.log('Auth check successful:', data);
          setUser(data.user);
        } else {
          console.log('Auth check failed - not authenticated');
        }
      } catch (error) {
        console.error('Auth check failed:', error);
      } finally {
        setLoading(false);
      }
    };

    checkAuth();
  }, []);

  // Login function
  const login = async (username: string, password: string) => {
    setLoading(true);
    try {
      console.log('Attempting login for:', username);
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        credentials: 'include',
        body: JSON.stringify({ username, password })
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        console.error('Login response error:', errorData);
        throw new Error(errorData.message || 'Login failed');
      }
      
      const data = await response.json();
      console.log('Login successful:', data);
      
      setUser(data.user);
      
      // Redirect based on role
      if (data.user.role === 'super_admin') {
        setLocation('/super-admin');
      } else {
        setLocation('/restaurant-admin/menu');
      }
    } catch (error) {
      console.error('Login failed:', error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  // Logout function
  const logout = async () => {
    setLoading(true);
    try {
      console.log('Attempting logout');
      const response = await fetch('/api/auth/logout', {
        method: 'POST',
        credentials: 'include'
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        console.error('Logout response error:', errorData);
        throw new Error(errorData.message || 'Logout failed');
      }
      
      console.log('Logout successful');
      setUser(null);
      setLocation('/');
    } catch (error) {
      console.error('Logout failed:', error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  return React.createElement(AuthContext.Provider, 
    {value: { user, loading, login, logout }}, 
    children
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

// Helper hook to require authentication
export function useRequireAuth(redirectTo: string = '/') {
  const { user, loading } = useAuth();
  const [, setLocation] = useLocation();
  
  useEffect(() => {
    if (!loading && !user) {
      setLocation(redirectTo);
    }
  }, [user, loading, redirectTo, setLocation]);
  
  return { user, loading };
}

// Helper hook to require a specific role
export function useRequireRole(role: UserRole, redirectTo: string = '/') {
  const { user, loading } = useAuth();
  const [, setLocation] = useLocation();
  
  useEffect(() => {
    if (!loading) {
      if (!user) {
        setLocation(redirectTo);
      } else if (user.role !== role && !(role === 'restaurant_admin' && user.role === 'super_admin')) {
        // Super admins can access restaurant admin pages, but not vice versa
        setLocation(redirectTo);
      }
    }
  }, [user, loading, role, redirectTo, setLocation]);
  
  return { user, loading };
}