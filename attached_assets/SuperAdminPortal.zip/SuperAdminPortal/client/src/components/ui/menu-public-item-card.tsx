import { MenuItem } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface MenuPublicItemCardProps {
  item: MenuItem;
  primaryColor?: string;
  isRtl?: boolean;
}

export default function MenuPublicItemCard({ 
  item,
  primaryColor,
  isRtl = false
}: MenuPublicItemCardProps) {
  return (
    <Card className="overflow-hidden hover:shadow-md transition-shadow">
      <div className="h-48 bg-gray-200 relative">
        {item.image ? (
          <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-gray-500">
            No image
          </div>
        )}
      </div>
      <CardContent className="p-4">
        <div className={cn(
          "flex justify-between items-start",
          isRtl && "flex-row-reverse"
        )}>
          <h3 className="font-bold text-lg">{item.name}</h3>
          <span 
            className="font-semibold"
            style={{ color: primaryColor || 'var(--primary)' }}
          >
            {item.price}
          </span>
        </div>
        <p className={cn(
          "text-gray-600 mt-2 text-sm",
          isRtl && "text-right"
        )}>
          {item.description}
        </p>
      </CardContent>
    </Card>
  );
}
