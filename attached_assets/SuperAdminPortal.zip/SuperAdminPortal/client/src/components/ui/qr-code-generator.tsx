import { useState, useRef } from 'react';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Download, Printer, Link2 } from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';

interface QRCodeGeneratorProps {
  menuUrl: string;
  restaurantName: string;
  logoUrl?: string;
}

export default function QRCodeGenerator({ 
  menuUrl, 
  restaurantName,
  logoUrl 
}: QRCodeGeneratorProps) {
  const [qrSize, setQrSize] = useState<string>("medium");
  const [fgColor, setFgColor] = useState<string>("#000000");
  const [bgColor, setBgColor] = useState<string>("#FFFFFF");
  const [includeLogo, setIncludeLogo] = useState<boolean>(false);
  const qrRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  const sizesMap = {
    small: 128,
    medium: 200,
    large: 300
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(menuUrl);
    toast({
      title: "URL Copied",
      description: "Menu URL has been copied to clipboard"
    });
  };

  const downloadQR = () => {
    if (!qrRef.current) return;
    
    // For SVG, we need to get the SVG element and create a data URL
    const svg = qrRef.current.querySelector('svg');
    if (!svg) return;
    
    // Create a canvas to convert SVG to image
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    // Set canvas size to match SVG size
    const svgSize = sizesMap[qrSize as keyof typeof sizesMap];
    canvas.width = svgSize;
    canvas.height = svgSize;
    
    // Create a Blob from the SVG string
    const svgString = new XMLSerializer().serializeToString(svg);
    const svgBlob = new Blob([svgString], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(svgBlob);
    
    // Create an image from the SVG and draw it on the canvas when loaded
    const img = new Image();
    img.onload = () => {
      ctx.drawImage(img, 0, 0);
      URL.revokeObjectURL(url);
      
      // Get data URL from canvas
      const image = canvas.toDataURL("image/png");
      
      // Create download link
      const link = document.createElement('a');
      link.href = image;
      link.download = `${restaurantName.replace(/\s+/g, '-').toLowerCase()}-menu-qr.png`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    };
    img.src = url;
  };

  const printQR = () => {
    if (!qrRef.current) return;
    
    const svg = qrRef.current.querySelector('svg');
    if (!svg) return;
    
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;
    
    // Create a canvas to convert SVG to image
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    // Set canvas size to match SVG size
    const svgSize = sizesMap[qrSize as keyof typeof sizesMap];
    canvas.width = svgSize;
    canvas.height = svgSize;
    
    // Create a Blob from the SVG string
    const svgString = new XMLSerializer().serializeToString(svg);
    const svgBlob = new Blob([svgString], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(svgBlob);
    
    // Create an image from the SVG and draw it on the canvas when loaded
    const img = new Image();
    img.onload = () => {
      ctx.drawImage(img, 0, 0);
      URL.revokeObjectURL(url);
      
      // Get data URL from canvas
      const image = canvas.toDataURL("image/png");
      
      // Create print window
      printWindow.document.write(`
        <html>
          <head>
            <title>${restaurantName} Menu QR Code</title>
            <style>
              body {
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                height: 100vh;
                font-family: Arial, sans-serif;
              }
              img {
                max-width: 100%;
                height: auto;
              }
              h1, p {
                text-align: center;
              }
            </style>
          </head>
          <body>
            <h1>${restaurantName} Menu</h1>
            <img src="${image}" alt="QR Code" />
            <p>Scan to view our menu</p>
            <script>
              window.onload = function() {
                window.print();
                window.setTimeout(function() {
                  window.close();
                }, 500);
              }
            </script>
          </body>
        </html>
      `);
    };
    img.src = url;
  };

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex flex-col md:flex-row items-start">
          <div className="md:w-1/3 p-6 flex flex-col items-center">
            <div 
              ref={qrRef}
              className="bg-white border border-gray-200 p-4 rounded-lg shadow-sm mb-4 flex items-center justify-center"
            >
              <QRCodeSVG
                value={menuUrl}
                size={sizesMap[qrSize as keyof typeof sizesMap]}
                fgColor={fgColor}
                bgColor={bgColor}
                level="H"
                imageSettings={includeLogo && logoUrl ? {
                  src: logoUrl,
                  excavate: true,
                  height: sizesMap[qrSize as keyof typeof sizesMap] * 0.2,
                  width: sizesMap[qrSize as keyof typeof sizesMap] * 0.2,
                } : undefined}
              />
            </div>
            <div className="flex space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={downloadQR}
                className="flex items-center"
              >
                <Download className="h-4 w-4 mr-1" />
                Download
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={printQR}
                className="flex items-center"
              >
                <Printer className="h-4 w-4 mr-1" />
                Print
              </Button>
            </div>
          </div>
          
          <div className="md:w-2/3 md:pl-6 mt-6 md:mt-0">
            <h3 className="text-lg font-medium text-gray-800 mb-4">Customize QR Code</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <div className="space-y-1">
                <Label htmlFor="menu-url">Menu URL</Label>
                <div className="flex">
                  <Input
                    id="menu-url"
                    value={menuUrl}
                    readOnly
                    className="flex-1 rounded-r-none bg-gray-50"
                  />
                  <Button
                    type="button"
                    variant="secondary"
                    className="rounded-l-none border border-input border-l-0"
                    onClick={copyToClipboard}
                  >
                    <Link2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              
              <div className="space-y-1">
                <Label htmlFor="qr-size">QR Code Size</Label>
                <Select 
                  value={qrSize} 
                  onValueChange={setQrSize}
                >
                  <SelectTrigger id="qr-size">
                    <SelectValue placeholder="Select size" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="small">Small (128x128px)</SelectItem>
                    <SelectItem value="medium">Medium (200x200px)</SelectItem>
                    <SelectItem value="large">Large (300x300px)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <div className="space-y-1">
                <Label htmlFor="fg-color">Foreground Color</Label>
                <div className="flex items-center">
                  <div 
                    className="w-8 h-8 rounded mr-2 border border-gray-300"
                    style={{ backgroundColor: fgColor }}
                  ></div>
                  <Input
                    id="fg-color"
                    type="text"
                    value={fgColor}
                    onChange={(e) => setFgColor(e.target.value)}
                  />
                </div>
              </div>
              
              <div className="space-y-1">
                <Label htmlFor="bg-color">Background Color</Label>
                <div className="flex items-center">
                  <div 
                    className="w-8 h-8 rounded mr-2 border border-gray-300"
                    style={{ backgroundColor: bgColor }}
                  ></div>
                  <Input
                    id="bg-color"
                    type="text"
                    value={bgColor}
                    onChange={(e) => setBgColor(e.target.value)}
                  />
                </div>
              </div>
            </div>
            
            <div className="mb-6">
              <div className="flex items-center space-x-2">
                <Switch
                  id="include-logo"
                  checked={includeLogo}
                  onCheckedChange={setIncludeLogo}
                  disabled={!logoUrl}
                />
                <Label htmlFor="include-logo">
                  Add restaurant logo to center of QR code
                </Label>
              </div>
              <p className="text-xs text-gray-500 mt-1">
                Note: Adding a logo may reduce QR code readability in some cases
              </p>
            </div>
            
            <div className="bg-gray-50 p-4 rounded-lg mt-6">
              <h4 className="font-medium text-gray-800 mb-2">Usage Instructions</h4>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <div className="flex-shrink-0 w-7 h-7 rounded-full bg-primary-100 flex items-center justify-center mr-3">
                    <span className="text-primary font-medium">1</span>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Print and place QR codes on table tents, physical menus, or posters.</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <div className="flex-shrink-0 w-7 h-7 rounded-full bg-primary-100 flex items-center justify-center mr-3">
                    <span className="text-primary font-medium">2</span>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Post the QR code on your social media profiles and stories.</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <div className="flex-shrink-0 w-7 h-7 rounded-full bg-primary-100 flex items-center justify-center mr-3">
                    <span className="text-primary font-medium">3</span>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Add QR codes to email signatures, business cards, and promotional materials.</p>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
