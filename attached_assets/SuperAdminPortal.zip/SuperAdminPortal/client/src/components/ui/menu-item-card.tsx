import { MenuItem } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Edit, Trash } from "lucide-react";

interface MenuItemCardProps {
  item: MenuItem;
  onEdit?: () => void;
  onDelete?: () => void;
  showActions?: boolean;
  primaryColor?: string;
}

export default function MenuItemCard({ 
  item,
  onEdit,
  onDelete,
  showActions = false,
  primaryColor
}: MenuItemCardProps) {
  return (
    <Card className="overflow-hidden hover:shadow-md transition-shadow">
      <div className="h-48 bg-gray-200 flex items-center justify-center">
        {item.image ? (
          <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
        ) : (
          <div className="text-gray-500">No image</div>
        )}
      </div>
      <CardContent className="p-4">
        <div className="flex justify-between items-start">
          <h3 className="font-bold text-lg">{item.name}</h3>
          <span 
            className="font-semibold"
            style={{ color: primaryColor || 'var(--primary)' }}
          >
            {item.price}
          </span>
        </div>
        <p className="text-gray-600 mt-2 text-sm">{item.description}</p>
        
        {showActions && (
          <div className="mt-4 flex justify-between items-center">
            <span className="px-2 py-1 text-xs font-medium bg-gray-100 rounded-full text-gray-600">
              {formatCategory(item.category)}
            </span>
            <div className="flex space-x-1">
              <Button 
                variant="ghost" 
                size="icon"
                onClick={onEdit}
                className="text-blue-500 hover:bg-blue-50 hover:text-blue-600"
              >
                <Edit className="h-4 w-4" />
              </Button>
              <Button 
                variant="ghost"
                size="icon"
                onClick={onDelete}
                className="text-red-500 hover:bg-red-50 hover:text-red-600"
              >
                <Trash className="h-4 w-4" />
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function formatCategory(category: string): string {
  switch (category) {
    case 'main':
      return 'Main Dish';
    case 'appetizers':
      return 'Appetizer';
    case 'drinks':
      return 'Drink';
    case 'desserts':
      return 'Dessert';
    default:
      return category.charAt(0).toUpperCase() + category.slice(1);
  }
}
