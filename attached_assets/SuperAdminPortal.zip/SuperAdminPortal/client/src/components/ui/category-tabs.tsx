import { useState } from "react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface CategoryTabsProps {
  categories: string[];
  onCategoryChange: (category: string | null) => void;
  activeCategory: string | null;
  primaryColor?: string;
  isRtl?: boolean;
}

export default function CategoryTabs({
  categories,
  onCategoryChange,
  activeCategory,
  primaryColor,
  isRtl = false
}: CategoryTabsProps) {
  const buttonStyleActive = {
    backgroundColor: primaryColor || 'var(--primary)',
    color: 'white'
  };

  return (
    <div 
      className={cn(
        "flex items-center overflow-x-auto py-3 -mx-1 custom-scrollbar",
        isRtl && "flex-row-reverse"
      )}
      dir={isRtl ? "rtl" : "ltr"}
    >
      <Button
        variant="outline"
        className={cn(
          "flex-shrink-0 px-4 py-2 mx-1 rounded-full text-sm font-medium",
          activeCategory === null && "bg-primary text-white"
        )}
        style={activeCategory === null ? buttonStyleActive : {}}
        onClick={() => onCategoryChange(null)}
      >
        All Items
      </Button>
      
      {categories.map((category) => (
        <Button
          key={category}
          variant="outline"
          className={cn(
            "flex-shrink-0 px-4 py-2 mx-1 rounded-full text-sm font-medium",
            activeCategory === category && "bg-primary text-white"
          )}
          style={activeCategory === category ? buttonStyleActive : {}}
          onClick={() => onCategoryChange(category)}
        >
          {formatCategory(category, isRtl)}
        </Button>
      ))}
    </div>
  );
}

function formatCategory(category: string, isRtl: boolean): string {
  if (isRtl) {
    switch (category) {
      case 'main':
        return 'الأطباق الرئيسية';
      case 'appetizers':
        return 'المقبلات';
      case 'drinks':
        return 'المشروبات';
      case 'desserts':
        return 'الحلويات';
      default:
        return category;
    }
  } else {
    switch (category) {
      case 'main':
        return 'Main Dishes';
      case 'appetizers':
        return 'Appetizers';
      case 'drinks':
        return 'Drinks';
      case 'desserts':
        return 'Desserts';
      default:
        return category.charAt(0).toUpperCase() + category.slice(1);
    }
  }
}
