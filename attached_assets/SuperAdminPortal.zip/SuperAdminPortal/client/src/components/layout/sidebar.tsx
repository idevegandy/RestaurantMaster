import { useState, ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/lib/auth";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Coffee,
  LayoutGrid,
  PaintBucket,
  QrCode,
  Mail,
  LogOut,
  Eye,
  User,
  Menu,
  X
} from "lucide-react";
import { useMobile } from "@/hooks/use-mobile";

interface SidebarProps {
  title: string;
  subtitle: string;
  logo?: string;
  logoText?: string;
  routes: Array<{
    href: string;
    label: string;
    icon: ReactNode;
    active?: boolean;
  }>;
  children?: ReactNode;
}

export function Sidebar({ title, subtitle, logo, logoText, routes, children }: SidebarProps) {
  const { logout } = useAuth();
  const isMobile = useMobile();
  const [expanded, setExpanded] = useState(!isMobile);
  
  const handleLogout = async () => {
    try {
      await logout();
    } catch (error) {
      console.error("Logout failed:", error);
    }
  };

  const toggleSidebar = () => {
    setExpanded(!expanded);
  };

  return (
    <div className="h-screen flex flex-col bg-primary-700 text-white">
      {isMobile && (
        <div className="flex justify-between items-center p-4 border-b border-primary-600">
          <div className="flex items-center">
            {logo ? (
              <div className="h-8 w-8 bg-white rounded-md flex items-center justify-center mr-2">
                <img src={logo} alt={title} className="h-6 w-6" />
              </div>
            ) : logoText ? (
              <div className="h-8 w-8 bg-white rounded-md flex items-center justify-center mr-2">
                <span className="text-primary-600 font-bold text-sm">{logoText}</span>
              </div>
            ) : null}
            <span className="font-bold">{title}</span>
          </div>
          <Button 
            variant="ghost" 
            size="icon"
            onClick={toggleSidebar}
            className="text-white hover:bg-primary-600"
          >
            {expanded ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </div>
      )}
      
      <div className={cn(
        "flex-col border-b border-primary-600",
        expanded ? "flex" : "hidden",
        !isMobile ? "p-6" : "p-4"
      )}>
        {!isMobile && (
          <>
            {logo ? (
              <div className="h-12 w-12 bg-white rounded-lg flex items-center justify-center mx-auto mb-2">
                <img src={logo} alt={title} className="h-8 w-8" />
              </div>
            ) : logoText ? (
              <div className="h-12 w-12 bg-white rounded-lg flex items-center justify-center mx-auto mb-2">
                <span className="text-primary-600 font-bold text-xl">{logoText}</span>
              </div>
            ) : null}
            <h1 className="text-xl font-bold text-center">{title}</h1>
            <p className="text-xs text-primary-300 text-center mt-1">{subtitle}</p>
          </>
        )}
      </div>
      
      <nav className={cn(
        "mt-6 px-4 flex-1",
        expanded ? "flex flex-col" : "hidden"
      )}>
        {routes.map((route, index) => (
          <Link 
            key={index} 
            href={route.href}
          >
            <a className={cn(
              "flex items-center px-2 py-2 mb-1 rounded-md transition",
              route.active ? "bg-primary-800" : "hover:bg-primary-800"
            )}>
              {route.icon}
              <span className="ml-3">{route.label}</span>
            </a>
          </Link>
        ))}
      </nav>
      
      <div className={cn(
        "mt-auto p-4 border-t border-primary-600",
        expanded ? "block" : "hidden"
      )}>
        {children}
        
        <button 
          onClick={handleLogout}
          className="flex items-center text-sm text-white opacity-80 hover:opacity-100"
        >
          <LogOut className="h-5 w-5 mr-2" />
          Logout
        </button>
      </div>
    </div>
  );
}

export function RestaurantSidebar() {
  const [location] = useLocation();
  const { user } = useAuth();
  
  const routes = [
    {
      href: "/restaurant-admin/menu",
      label: "Menu Items",
      icon: <Coffee className="h-5 w-5 mr-3" />,
      active: location === "/restaurant-admin/menu"
    },
    {
      href: "/restaurant-admin/branding",
      label: "Theme & Branding",
      icon: <PaintBucket className="h-5 w-5 mr-3" />,
      active: location === "/restaurant-admin/branding"
    },
    {
      href: "/restaurant-admin/qr-code",
      label: "QR Code",
      icon: <QrCode className="h-5 w-5 mr-3" />,
      active: location === "/restaurant-admin/qr-code"
    },
    {
      href: "/restaurant-admin/contact",
      label: "Contact Information",
      icon: <Mail className="h-5 w-5 mr-3" />,
      active: location === "/restaurant-admin/contact"
    }
  ];
  
  return (
    <Sidebar
      title={user?.username || "Restaurant"}
      subtitle="Restaurant Admin"
      logoText="RM"
      routes={routes}
    >
      <Link href={`/menu/${user?.restaurantId}`}>
        <a className="flex items-center justify-center px-4 py-2 text-sm bg-white text-primary-700 rounded-md hover:bg-gray-100 transition mb-3">
          <Eye className="h-4 w-4 mr-2" />
          Preview Menu
        </a>
      </Link>
    </Sidebar>
  );
}

export function SuperAdminSidebar() {
  const [location] = useLocation();
  
  const routes = [
    {
      href: "/super-admin",
      label: "Dashboard",
      icon: <LayoutGrid className="h-5 w-5 mr-3" />,
      active: location === "/super-admin"
    },
    {
      href: "/super-admin/restaurants",
      label: "Restaurants",
      icon: <Coffee className="h-5 w-5 mr-3" />,
      active: location === "/super-admin/restaurants"
    },
    {
      href: "/super-admin/users",
      label: "Users",
      icon: <User className="h-5 w-5 mr-3" />,
      active: location === "/super-admin/users"
    }
  ];
  
  return (
    <Sidebar
      title="Digital Menu"
      subtitle="Super Admin"
      routes={routes}
    />
  );
}
