import { ReactNode } from "react";
import { useRequireAuth } from "@/lib/auth";
import { RestaurantSidebar } from "./sidebar";
import { Skeleton } from "@/components/ui/skeleton";
import { useMobile } from "@/hooks/use-mobile";

interface RestaurantAdminLayoutProps {
  children: ReactNode;
  title: string;
  actions?: ReactNode;
}

export default function RestaurantAdminLayout({ 
  children, 
  title,
  actions 
}: RestaurantAdminLayoutProps) {
  const { user, loading } = useRequireAuth();
  const isMobile = useMobile();
  
  if (loading) {
    return <LoadingSkeleton />;
  }
  
  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <div className={isMobile ? "w-16" : "w-64"}>
        <RestaurantSidebar />
      </div>
      
      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="bg-white shadow-sm py-4 px-6">
          <div className="flex justify-between items-center">
            <h1 className="text-2xl font-bold text-gray-800">{title}</h1>
            
            <div className="flex items-center space-x-4">
              {actions}
            </div>
          </div>
        </header>
        
        <main className="flex-1 overflow-auto p-6">
          {children}
        </main>
      </div>
    </div>
  );
}

function LoadingSkeleton() {
  return (
    <div className="flex h-screen">
      <div className="w-64 bg-primary-800">
        <Skeleton className="h-full w-full" />
      </div>
      <div className="flex-1">
        <Skeleton className="h-16 w-full" />
        <div className="p-6">
          <Skeleton className="h-48 w-full mb-6" />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Skeleton className="h-64 w-full" />
            <Skeleton className="h-64 w-full" />
            <Skeleton className="h-64 w-full" />
          </div>
        </div>
      </div>
    </div>
  );
}
