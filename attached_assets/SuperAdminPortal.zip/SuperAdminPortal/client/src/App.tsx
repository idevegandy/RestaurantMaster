import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import LoginPage from "@/pages/login";
import SuperAdminDashboard from "@/pages/super-admin/dashboard";
import RestaurantsPage from "@/pages/super-admin/restaurants";
import UsersPage from "@/pages/super-admin/users";
import RestaurantMenu from "@/pages/restaurant-admin/menu";
import RestaurantBranding from "@/pages/restaurant-admin/branding";
import RestaurantQRCode from "@/pages/restaurant-admin/qr-code";
import RestaurantContact from "@/pages/restaurant-admin/contact";
import PublicMenu from "@/pages/public-menu";
import NotFound from "@/pages/not-found";
import { AuthProvider } from "./lib/auth";

function Router() {
  return (
    <Switch>
      {/* Public Routes */}
      <Route path="/" component={LoginPage} />
      <Route path="/menu/:slug" component={PublicMenu} />
      
      {/* Super Admin Routes */}
      <Route path="/super-admin" component={SuperAdminDashboard} />
      <Route path="/super-admin/restaurants" component={RestaurantsPage} />
      <Route path="/super-admin/users" component={UsersPage} />
      
      {/* Restaurant Admin Routes */}
      <Route path="/restaurant-admin/menu" component={RestaurantMenu} />
      <Route path="/restaurant-admin/branding" component={RestaurantBranding} />
      <Route path="/restaurant-admin/qr-code" component={RestaurantQRCode} />
      <Route path="/restaurant-admin/contact" component={RestaurantContact} />
      
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
