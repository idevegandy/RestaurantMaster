import { useQuery } from "@tanstack/react-query";
import RestaurantAdminLayout from "@/components/layout/restaurant-admin-layout";
import QRCodeGenerator from "@/components/ui/qr-code-generator";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

export default function RestaurantQRCode() {
  // Fetch restaurant data
  const { data, isLoading } = useQuery({
    queryKey: ['/api/restaurant']
  });
  
  const restaurant = data?.restaurant;
  
  // Construct the menu URL
  const baseUrl = window.location.origin;
  const menuUrl = restaurant ? `${baseUrl}/menu/${restaurant.slug}` : '';
  
  return (
    <RestaurantAdminLayout title="QR Code Generator">
      {isLoading ? (
        <Card>
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row">
              <div className="md:w-1/3 p-6 flex flex-col items-center">
                <Skeleton className="h-48 w-48 mb-4" />
                <div className="flex space-x-2">
                  <Skeleton className="h-10 w-24" />
                  <Skeleton className="h-10 w-24" />
                </div>
              </div>
              <div className="md:w-2/3 md:pl-6 mt-6 md:mt-0">
                <Skeleton className="h-8 w-48 mb-4" />
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                  <Skeleton className="h-10 w-full" />
                  <Skeleton className="h-10 w-full" />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                  <Skeleton className="h-10 w-full" />
                  <Skeleton className="h-10 w-full" />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      ) : restaurant ? (
        <QRCodeGenerator 
          menuUrl={menuUrl}
          restaurantName={restaurant.name}
          logoUrl={restaurant.settings.logo}
        />
      ) : (
        <div className="text-center py-8">
          <p className="text-gray-500">Restaurant information not found.</p>
        </div>
      )}
    </RestaurantAdminLayout>
  );
}
