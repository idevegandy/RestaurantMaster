import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import RestaurantAdminLayout from "@/components/layout/restaurant-admin-layout";
import MenuItemCard from "@/components/ui/menu-item-card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { 
  Plus, 
  Coffee, 
  UtensilsCrossed, 
  Soup, 
  IceCream, 
  GlassWater,
  MoveHorizontal, 
  Beef, 
  Salad,
  Pizza
} from "lucide-react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { MenuItem } from "@shared/schema";

export default function RestaurantMenu() {
  const { toast } = useToast();
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [editingItem, setEditingItem] = useState<MenuItem | null>(null);
  const [deletingItem, setDeletingItem] = useState<MenuItem | null>(null);
  
  // Form state
  const [formData, setFormData] = useState({
    name: '',
    price: '',
    description: '',
    category: 'main',
    image: ''
  });
  
  // Fetch restaurant data
  const { data: restaurantData, isLoading: restaurantLoading } = useQuery({
    queryKey: ['/api/restaurant']
  });
  
  // Fetch menu items
  const { data: menuData, isLoading: menuLoading } = useQuery({
    queryKey: ['/api/restaurant/menu-items']
  });
  
  const menuItems = menuData?.menuItems || [];
  const restaurant = restaurantData?.restaurant;
  
  // Get unique categories
  const categories = [...new Set(menuItems.map(item => item.category))];
  
  // Filter items by category
  const filteredItems = selectedCategory 
    ? menuItems.filter(item => item.category === selectedCategory) 
    : menuItems;
  
  // Add menu item mutation
  const createMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      try {
        console.log("Create request payload:", JSON.stringify(data, null, 2));
        const response = await apiRequest('POST', '/api/restaurant/menu-items', {
          name: data.name,
          price: data.price,
          description: data.description || null,
          category: data.category,
          image: data.image || null
        });
        const result = await response.json();
        console.log("Create response:", result);
        return result;
      } catch (error) {
        console.error("Create error:", error);
        throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/restaurant/menu-items'] });
      resetForm();
      setCreateDialogOpen(false);
      toast({
        title: "Item added",
        description: "Menu item has been added successfully."
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to add item: ${error.message}`,
        variant: "destructive"
      });
    }
  });
  
  // Update menu item mutation
  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number, data: typeof formData }) => {
      try {
        console.log("Update request payload:", JSON.stringify(data, null, 2));
        const response = await apiRequest('PATCH', `/api/restaurant/menu-items/${id}`, {
          name: data.name,
          price: data.price,
          description: data.description || null,
          category: data.category,
          image: data.image || null
        });
        const result = await response.json();
        console.log("Update response:", result);
        return result;
      } catch (error) {
        console.error("Update error:", error);
        throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/restaurant/menu-items'] });
      resetForm();
      setEditDialogOpen(false);
      toast({
        title: "Item updated",
        description: "Menu item has been updated successfully."
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update item: ${error.message}`,
        variant: "destructive"
      });
    }
  });
  
  // Delete menu item mutation
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/restaurant/menu-items/${id}`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/restaurant/menu-items'] });
      setDeleteDialogOpen(false);
      toast({
        title: "Item deleted",
        description: "Menu item has been deleted successfully."
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete item: ${error.message}`,
        variant: "destructive"
      });
    }
  });
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleSelectChange = (name: string, value: string) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({ ...prev, image: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };
  
  const resetForm = () => {
    setFormData({
      name: '',
      price: '',
      description: '',
      category: 'main',
      image: ''
    });
    setEditingItem(null);
  };
  
  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createMutation.mutate(formData);
  };
  
  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingItem) {
      updateMutation.mutate({ id: editingItem.id, data: formData });
    }
  };
  
  const handleEdit = (item: MenuItem) => {
    setEditingItem(item);
    setFormData({
      name: item.name,
      price: item.price,
      description: item.description || '',
      category: item.category,
      image: item.image || ''
    });
    setEditDialogOpen(true);
  };
  
  const handleDelete = (item: MenuItem) => {
    setDeletingItem(item);
    setDeleteDialogOpen(true);
  };
  
  const confirmDelete = () => {
    if (deletingItem) {
      deleteMutation.mutate(deletingItem.id);
    }
  };
  
  const isLoading = restaurantLoading || menuLoading;
  
  return (
    <RestaurantAdminLayout 
      title="Menu Management"
      actions={
        <Button
          onClick={() => {
            resetForm();
            setCreateDialogOpen(true);
          }}
          className="flex items-center"
        >
          <Plus className="h-5 w-5 mr-2" />
          Add New Item
        </Button>
      }
    >
      {/* Category Filter */}
      <div className="mb-6">
        <div className="flex items-center mb-4">
          <h2 className="text-lg font-semibold text-gray-800">Menu Items</h2>
          <div className="ml-auto">
            <Select
              value={selectedCategory || "all"}
              onValueChange={(value) => setSelectedCategory(value === "all" ? null : value)}
            >
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="All Categories" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                {categories.map(category => (
                  <SelectItem key={category} value={category}>
                    {formatCategory(category)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>
      
      {/* Menu Items Grid */}
      {isLoading ? (
        <div className="text-center py-8">Loading menu items...</div>
      ) : filteredItems.length === 0 ? (
        <div className="text-center py-8">
          <p className="text-gray-500 mb-4">No menu items found in this category.</p>
          <Button onClick={() => setCreateDialogOpen(true)}>Add Your First Item</Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map(item => (
            <MenuItemCard
              key={item.id}
              item={item}
              showActions
              onEdit={() => handleEdit(item)}
              onDelete={() => handleDelete(item)}
              primaryColor={restaurant?.settings.primaryColor}
            />
          ))}
        </div>
      )}
      
      {/* Create Menu Item Dialog */}
      <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Add New Menu Item</DialogTitle>
            <DialogDescription>
              Create a new item for your restaurant menu.
            </DialogDescription>
          </DialogHeader>
          
          <form onSubmit={handleCreateSubmit}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div className="space-y-1">
                <Label htmlFor="name">Item Name</Label>
                <Input
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  required
                />
              </div>
              
              <div className="space-y-1">
                <Label htmlFor="price">Price</Label>
                <Input
                  id="price"
                  name="price"
                  value={formData.price}
                  onChange={handleInputChange}
                  placeholder="e.g. 35 SAR"
                  required
                />
              </div>
              
              <div className="space-y-1 md:col-span-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  name="description"
                  value={formData.description}
                  onChange={handleInputChange}
                  rows={3}
                />
              </div>
              
              <div className="space-y-1">
                <Label htmlFor="category">Category</Label>
                <Select
                  value={formData.category}
                  onValueChange={(value) => handleSelectChange('category', value)}
                >
                  <SelectTrigger id="category">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="main" className="flex items-center">
                      <UtensilsCrossed className="w-4 h-4 mr-2" />
                      Main Dishes
                    </SelectItem>
                    <SelectItem value="appetizers" className="flex items-center">
                      <Salad className="w-4 h-4 mr-2" />
                      Appetizers
                    </SelectItem>
                    <SelectItem value="drinks" className="flex items-center">
                      <GlassWater className="w-4 h-4 mr-2" />
                      Drinks
                    </SelectItem>
                    <SelectItem value="desserts" className="flex items-center">
                      <IceCream className="w-4 h-4 mr-2" />
                      Desserts
                    </SelectItem>
                    <SelectItem value="entrees" className="flex items-center">
                      <Beef className="w-4 h-4 mr-2" />
                      Entrées
                    </SelectItem>
                    <SelectItem value="soups" className="flex items-center">
                      <Soup className="w-4 h-4 mr-2" />
                      Soups
                    </SelectItem>
                    <SelectItem value="coffee" className="flex items-center">
                      <Coffee className="w-4 h-4 mr-2" />
                      Coffee & Tea
                    </SelectItem>
                    <SelectItem value="pizza" className="flex items-center">
                      <Pizza className="w-4 h-4 mr-2" />
                      Pizza
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-1">
                <Label htmlFor="image">Image URL</Label>
                <Input
                  id="image"
                  name="image"
                  value={formData.image}
                  onChange={handleInputChange}
                  placeholder="Enter image URL"
                />
              </div>
            </div>
            
            <DialogFooter>
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setCreateDialogOpen(false)}
                disabled={createMutation.isPending}
              >
                Cancel
              </Button>
              <Button 
                type="submit"
                disabled={createMutation.isPending}
              >
                {createMutation.isPending ? "Adding..." : "Add Item"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
      
      {/* Edit Menu Item Dialog */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Edit Menu Item</DialogTitle>
            <DialogDescription>
              Update the details of your menu item.
            </DialogDescription>
          </DialogHeader>
          
          <form onSubmit={handleEditSubmit}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div className="space-y-1">
                <Label htmlFor="edit-name">Item Name</Label>
                <Input
                  id="edit-name"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  required
                />
              </div>
              
              <div className="space-y-1">
                <Label htmlFor="edit-price">Price</Label>
                <Input
                  id="edit-price"
                  name="price"
                  value={formData.price}
                  onChange={handleInputChange}
                  placeholder="e.g. 35 SAR"
                  required
                />
              </div>
              
              <div className="space-y-1 md:col-span-2">
                <Label htmlFor="edit-description">Description</Label>
                <Textarea
                  id="edit-description"
                  name="description"
                  value={formData.description}
                  onChange={handleInputChange}
                  rows={3}
                />
              </div>
              
              <div className="space-y-1">
                <Label htmlFor="edit-category">Category</Label>
                <Select
                  value={formData.category}
                  onValueChange={(value) => handleSelectChange('category', value)}
                >
                  <SelectTrigger id="edit-category">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="main" className="flex items-center">
                      <UtensilsCrossed className="w-4 h-4 mr-2" />
                      Main Dishes
                    </SelectItem>
                    <SelectItem value="appetizers" className="flex items-center">
                      <Salad className="w-4 h-4 mr-2" />
                      Appetizers
                    </SelectItem>
                    <SelectItem value="drinks" className="flex items-center">
                      <GlassWater className="w-4 h-4 mr-2" />
                      Drinks
                    </SelectItem>
                    <SelectItem value="desserts" className="flex items-center">
                      <IceCream className="w-4 h-4 mr-2" />
                      Desserts
                    </SelectItem>
                    <SelectItem value="entrees" className="flex items-center">
                      <Beef className="w-4 h-4 mr-2" />
                      Entrées
                    </SelectItem>
                    <SelectItem value="soups" className="flex items-center">
                      <Soup className="w-4 h-4 mr-2" />
                      Soups
                    </SelectItem>
                    <SelectItem value="coffee" className="flex items-center">
                      <Coffee className="w-4 h-4 mr-2" />
                      Coffee & Tea
                    </SelectItem>
                    <SelectItem value="pizza" className="flex items-center">
                      <Pizza className="w-4 h-4 mr-2" />
                      Pizza
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-1">
                <Label htmlFor="edit-image">Image URL</Label>
                <Input
                  id="edit-image"
                  name="image"
                  value={formData.image}
                  onChange={handleInputChange}
                  placeholder="Enter image URL"
                />
              </div>
            </div>
            
            <DialogFooter>
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setEditDialogOpen(false)}
                disabled={updateMutation.isPending}
              >
                Cancel
              </Button>
              <Button 
                type="submit"
                disabled={updateMutation.isPending}
              >
                {updateMutation.isPending ? "Updating..." : "Update Item"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
      
      {/* Delete Confirmation */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the menu item "{deletingItem?.name}".
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleteMutation.isPending}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              disabled={deleteMutation.isPending}
              className="bg-red-600 hover:bg-red-700"
            >
              {deleteMutation.isPending ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </RestaurantAdminLayout>
  );
}

function formatCategory(category: string): string {
  switch (category) {
    case 'main':
      return 'Main Dishes';
    case 'appetizers':
      return 'Appetizers';
    case 'drinks':
      return 'Drinks';
    case 'desserts':
      return 'Desserts';
    case 'entrees':
      return 'Entrées';
    case 'soups':
      return 'Soups';
    case 'coffee':
      return 'Coffee & Tea';
    case 'pizza':
      return 'Pizza';
    default:
      return category.charAt(0).toUpperCase() + category.slice(1);
  }
}
