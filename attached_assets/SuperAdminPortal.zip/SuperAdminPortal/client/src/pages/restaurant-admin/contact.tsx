import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import RestaurantAdminLayout from "@/components/layout/restaurant-admin-layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Mail, Phone, Facebook, Instagram, Clock } from "lucide-react";
import { queryClient, apiRequest } from "@/lib/queryClient";

export default function RestaurantContact() {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    email: '',
    phone: '',
    facebook: '',
    instagram: '',
    weekdaysHours: '',
    weekendHours: ''
  });
  
  // Fetch restaurant data
  const { data, isLoading } = useQuery({
    queryKey: ['/api/restaurant']
  });
  
  // Set initial form data from restaurant settings
  useEffect(() => {
    if (data?.restaurant) {
      const { contact } = data.restaurant.settings;
      setFormData({
        email: contact.email || '',
        phone: contact.phone || '',
        facebook: contact.facebook || '',
        instagram: contact.instagram || '',
        weekdaysHours: contact.hours?.weekdays || 'Monday - Thursday: 11:00 AM - 10:00 PM',
        weekendHours: contact.hours?.weekend || 'Friday - Sunday: 11:00 AM - 11:00 PM'
      });
    }
  }, [data]);
  
  // Update contact information mutation
  const updateMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const response = await apiRequest('PATCH', '/api/restaurant/settings', {
        contact: {
          email: data.email,
          phone: data.phone,
          facebook: data.facebook,
          instagram: data.instagram,
          hours: {
            weekdays: data.weekdaysHours,
            weekend: data.weekendHours
          }
        }
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/restaurant'] });
      toast({
        title: "Contact updated",
        description: "Your contact information has been updated successfully."
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update contact information: ${error.message}`,
        variant: "destructive"
      });
    }
  });
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateMutation.mutate(formData);
  };
  
  return (
    <RestaurantAdminLayout title="Contact Information">
      <form onSubmit={handleSubmit}>
        <Card className="mb-8">
          <CardContent className="p-6">
            <h3 className="text-lg font-medium text-gray-800 mb-6">Basic Contact Information</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div className="space-y-2">
                <Label htmlFor="email" className="flex items-center">
                  <Mail className="h-4 w-4 mr-2 text-gray-500" />
                  Email Address
                </Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  placeholder="contact@yourrestaurant.com"
                  value={formData.email}
                  onChange={handleInputChange}
                />
                <p className="text-xs text-gray-500">
                  Primary email address for customer inquiries
                </p>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="phone" className="flex items-center">
                  <Phone className="h-4 w-4 mr-2 text-gray-500" />
                  Phone Number
                </Label>
                <Input
                  id="phone"
                  name="phone"
                  type="text"
                  placeholder="+1 (555) 123-4567"
                  value={formData.phone}
                  onChange={handleInputChange}
                />
                <p className="text-xs text-gray-500">
                  Phone number for reservations and inquiries
                </p>
              </div>
            </div>
            
            <h3 className="text-lg font-medium text-gray-800 mb-6">Social Media</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div className="space-y-2">
                <Label htmlFor="facebook" className="flex items-center">
                  <Facebook className="h-4 w-4 mr-2 text-gray-500" />
                  Facebook
                </Label>
                <Input
                  id="facebook"
                  name="facebook"
                  type="text"
                  placeholder="yourrestaurant"
                  value={formData.facebook}
                  onChange={handleInputChange}
                />
                <p className="text-xs text-gray-500">
                  Your Facebook page username (e.g. yourrestaurant)
                </p>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="instagram" className="flex items-center">
                  <Instagram className="h-4 w-4 mr-2 text-gray-500" />
                  Instagram
                </Label>
                <Input
                  id="instagram"
                  name="instagram"
                  type="text"
                  placeholder="yourrestaurant"
                  value={formData.instagram}
                  onChange={handleInputChange}
                />
                <p className="text-xs text-gray-500">
                  Your Instagram username (e.g. yourrestaurant)
                </p>
              </div>
            </div>
            
            <h3 className="text-lg font-medium text-gray-800 mb-6">Business Hours</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div className="space-y-2">
                <Label htmlFor="weekdaysHours" className="flex items-center">
                  <Clock className="h-4 w-4 mr-2 text-gray-500" />
                  Weekdays
                </Label>
                <Input
                  id="weekdaysHours"
                  name="weekdaysHours"
                  type="text"
                  placeholder="Monday - Thursday: 11:00 AM - 10:00 PM"
                  value={formData.weekdaysHours}
                  onChange={handleInputChange}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="weekendHours" className="flex items-center">
                  <Clock className="h-4 w-4 mr-2 text-gray-500" />
                  Weekend
                </Label>
                <Input
                  id="weekendHours"
                  name="weekendHours"
                  type="text"
                  placeholder="Friday - Sunday: 11:00 AM - 11:00 PM"
                  value={formData.weekendHours}
                  onChange={handleInputChange}
                />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <div className="flex justify-end">
          <Button 
            type="submit"
            disabled={updateMutation.isPending || isLoading}
          >
            {updateMutation.isPending ? "Saving..." : "Save Contact Information"}
          </Button>
        </div>
      </form>
    </RestaurantAdminLayout>
  );
}
