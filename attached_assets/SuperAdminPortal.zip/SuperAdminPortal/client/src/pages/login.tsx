import { useState } from "react";
import { useAuth } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function LoginPage() {
  const [activeTab, setActiveTab] = useState<"super_admin" | "restaurant_admin">("super_admin");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  
  const { login } = useAuth();
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    try {
      await login(username, password);
    } catch (error) {
      console.error("Login error:", error);
      toast({
        title: "Login failed",
        description: "Invalid username or password. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <Card className="w-full max-w-md mx-4">
        <CardContent className="pt-6">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-primary">Digital Menu</h1>
            <p className="text-gray-600 mt-2">Sign in to manage your restaurant</p>
          </div>
          
          <Tabs 
            defaultValue="super_admin" 
            value={activeTab}
            onValueChange={(value) => setActiveTab(value as "super_admin" | "restaurant_admin")}
            className="mb-6"
          >
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="super_admin">Super Admin</TabsTrigger>
              <TabsTrigger value="restaurant_admin">Restaurant Admin</TabsTrigger>
            </TabsList>
          </Tabs>
          
          <form className="space-y-6" onSubmit={handleSubmit}>
            <div className="space-y-1">
              <Label htmlFor="username">Username</Label>
              <Input
                id="username"
                type="text"
                placeholder="Enter your username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
                disabled={isLoading}
              />
            </div>
            
            <div className="space-y-1">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                disabled={isLoading}
              />
            </div>
            
            <Button type="submit" className="w-full" disabled={isLoading}>
              {isLoading ? "Signing in..." : "Sign In"}
            </Button>
          </form>
          
          {activeTab === "super_admin" && (
            <div className="mt-4 text-xs text-center text-gray-500">
              Default Super Admin credentials: <br />
              Username: admin, Password: admin123
            </div>
          )}
          
          {activeTab === "restaurant_admin" && (
            <div className="mt-4 text-xs text-center text-gray-500">
              Default Restaurant Admin credentials: <br />
              Username: owner1, Password: pass1
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
