import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useParams } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import CategoryTabs from "@/components/ui/category-tabs";
import MenuPublicItemCard from "@/components/ui/menu-public-item-card";
import { Facebook, Instagram, Phone, Mail, Clock } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";

export default function PublicMenu() {
  const { slug } = useParams();
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [isRtl, setIsRtl] = useState(false);
  
  // Fetch restaurant menu data
  const { data, isLoading, error } = useQuery({
    queryKey: [`/api/public/menu/${slug}`]
  });
  
  // Set RTL direction based on restaurant settings
  useEffect(() => {
    if (data?.restaurant.settings.textDirection === 'rtl') {
      setIsRtl(true);
      document.documentElement.dir = 'rtl';
    } else {
      setIsRtl(false);
      document.documentElement.dir = 'ltr';
    }
    
    return () => {
      // Reset direction when unmounting
      document.documentElement.dir = 'ltr';
    };
  }, [data]);
  
  if (isLoading) {
    return <LoadingSkeleton />;
  }
  
  if (error || !data) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Card className="max-w-md mx-auto">
          <CardContent className="p-6">
            <h1 className="text-xl font-bold text-red-600 mb-2">Menu Not Found</h1>
            <p className="text-gray-600">
              Sorry, the restaurant menu you're looking for doesn't exist or is temporarily unavailable.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  const { restaurant, menuItems } = data;
  const settings = restaurant.settings;
  
  // Get unique categories
  const categories = [...new Set(menuItems.map((item: any) => item.category))];
  
  // Filter items by category
  const filteredItems = activeCategory 
    ? menuItems.filter((item: any) => item.category === activeCategory) 
    : menuItems;
  
  // Group menu items by category for display
  const groupedItems = filteredItems.reduce((acc: any, item: any) => {
    if (!acc[item.category]) {
      acc[item.category] = [];
    }
    acc[item.category].push(item);
    return acc;
  }, {});
  
  const categoryDisplayOrder = ['main', 'appetizers', 'drinks', 'desserts'];
  
  // Sort categories for display
  const sortedCategories = Object.keys(groupedItems).sort((a, b) => {
    const indexA = categoryDisplayOrder.indexOf(a);
    const indexB = categoryDisplayOrder.indexOf(b);
    return (indexA === -1 ? 999 : indexA) - (indexB === -1 ? 999 : indexB);
  });
  
  // Apply custom styles based on restaurant settings
  const headerStyle = {
    backgroundColor: settings.primaryColor
  };
  
  const buttonStyle = {
    backgroundColor: settings.primaryColor,
    color: 'white'
  };
  
  return (
    <div 
      className="min-h-screen bg-gray-50" 
      dir={isRtl ? "rtl" : "ltr"}
    >
      {/* Header */}
      <header className="shadow-sm" style={headerStyle}>
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className={cn(
              "flex items-center mb-4 md:mb-0",
              isRtl ? "flex-row-reverse" : "flex-row"
            )}>
              <div className="h-14 w-14 bg-white rounded-full flex items-center justify-center shadow-md overflow-hidden">
                {settings.logo ? (
                  <img src={settings.logo} alt={restaurant.name} className="h-full w-full object-cover" />
                ) : (
                  <span className="text-primary-600 font-bold text-xl">
                    {restaurant.name.charAt(0)}
                  </span>
                )}
              </div>
              <div className={isRtl ? "mr-3" : "ml-3"}>
                <h1 className="text-2xl font-bold text-white">{restaurant.name}</h1>
                <p className="text-primary-100 text-sm">
                  {isRtl ? "مأكولات شهية وخدمة ممتازة" : "Delicious Food & Great Service"}
                </p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              {settings.contact.facebook && (
                <a 
                  href={`https://facebook.com/${settings.contact.facebook}`} 
                  className="text-white hover:text-primary-100 transition"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <Facebook className={cn("h-6 w-6", isRtl && "rtl-flip")} />
                </a>
              )}
              
              {settings.contact.instagram && (
                <a 
                  href={`https://instagram.com/${settings.contact.instagram}`}  
                  className="text-white hover:text-primary-100 transition"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <Instagram className={cn("h-6 w-6", isRtl && "rtl-flip")} />
                </a>
              )}
              
              {settings.contact.phone && (
                <a 
                  href={`tel:${settings.contact.phone}`}
                  className="text-white hover:text-primary-100 transition"
                >
                  <Phone className={cn("h-6 w-6", isRtl && "rtl-flip")} />
                </a>
              )}
            </div>
          </div>
        </div>
      </header>
      
      {/* Categories Navigation */}
      <div className="sticky top-0 z-10 bg-white shadow-sm border-b">
        <div className="container mx-auto px-4">
          <CategoryTabs
            categories={categories}
            onCategoryChange={setActiveCategory}
            activeCategory={activeCategory}
            primaryColor={settings.primaryColor}
            isRtl={isRtl}
          />
        </div>
      </div>
      
      {/* Main Menu Content */}
      <main className="container mx-auto px-4 py-8">
        {activeCategory ? (
          // Show only the selected category
          <section className="mb-12">
            <h2 className={cn(
              "text-xl font-bold mb-6 text-gray-900",
              isRtl && "text-right"
            )}>
              {formatCategory(activeCategory, isRtl)}
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {groupedItems[activeCategory].map((item: any) => (
                <MenuPublicItemCard
                  key={item.id}
                  item={item}
                  primaryColor={settings.primaryColor}
                  isRtl={isRtl}
                />
              ))}
            </div>
          </section>
        ) : (
          // Show all categories
          sortedCategories.map((category) => (
            <section key={category} className="mb-12">
              <h2 className={cn(
                "text-xl font-bold mb-6 text-gray-900",
                isRtl && "text-right"
              )}>
                {formatCategory(category, isRtl)}
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {groupedItems[category].map((item: any) => (
                  <MenuPublicItemCard
                    key={item.id}
                    item={item}
                    primaryColor={settings.primaryColor}
                    isRtl={isRtl}
                  />
                ))}
              </div>
            </section>
          ))
        )}
      </main>
      
      {/* Footer */}
      <footer className="bg-gray-800 text-white py-8">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className={isRtl ? "text-right" : ""}>
              <h3 className="text-lg font-semibold mb-4">{restaurant.name}</h3>
              <p className="text-gray-400 text-sm">
                {isRtl 
                  ? "استمتع بتجربة طعام فريدة مع قائمتنا المعدة بعناية"
                  : "Experience the authentic taste with our carefully crafted menu."}
              </p>
            </div>
            
            <div className={isRtl ? "text-right" : ""}>
              <h3 className="text-lg font-semibold mb-4">
                {isRtl ? "اتصل بنا" : "Contact"}
              </h3>
              <ul className="text-gray-400 text-sm space-y-2">
                {settings.contact.phone && (
                  <li className={cn(
                    "flex items-center",
                    isRtl ? "flex-row-reverse" : ""
                  )}>
                    <Phone className={cn(
                      "h-5 w-5 text-gray-500",
                      isRtl ? "mr-2 rtl-flip" : "mr-2"
                    )} />
                    {settings.contact.phone}
                  </li>
                )}
                
                {settings.contact.email && (
                  <li className={cn(
                    "flex items-center",
                    isRtl ? "flex-row-reverse" : ""
                  )}>
                    <Mail className={cn(
                      "h-5 w-5 text-gray-500",
                      isRtl ? "mr-2" : "mr-2"
                    )} />
                    {settings.contact.email}
                  </li>
                )}
              </ul>
            </div>
            
            <div className={isRtl ? "text-right" : ""}>
              <h3 className="text-lg font-semibold mb-4">
                {isRtl ? "ساعات العمل" : "Hours"}
              </h3>
              <ul className="text-gray-400 text-sm space-y-2">
                {settings.contact.hours?.weekdays && (
                  <li className={cn(
                    "flex items-start",
                    isRtl ? "flex-row-reverse" : ""
                  )}>
                    <Clock className={cn(
                      "h-5 w-5 text-gray-500 mt-0.5",
                      isRtl ? "ml-2" : "mr-2"
                    )} />
                    <span>{settings.contact.hours.weekdays}</span>
                  </li>
                )}
                
                {settings.contact.hours?.weekend && (
                  <li className={cn(
                    "flex items-start",
                    isRtl ? "flex-row-reverse" : ""
                  )}>
                    <Clock className={cn(
                      "h-5 w-5 text-gray-500 mt-0.5 opacity-0",
                      isRtl ? "ml-2" : "mr-2"
                    )} />
                    <span>{settings.contact.hours.weekend}</span>
                  </li>
                )}
              </ul>
            </div>
          </div>
          
          <div className={cn(
            "border-t border-gray-700 mt-8 pt-6 flex flex-col md:flex-row justify-between items-center",
            isRtl && "text-right"
          )}>
            <p className="text-gray-500 text-sm mb-4 md:mb-0">
              © {new Date().getFullYear()} {restaurant.name}. {isRtl ? "جميع الحقوق محفوظة." : "All rights reserved."}
            </p>
            <div className="flex space-x-4">
              {settings.contact.facebook && (
                <a 
                  href={`https://facebook.com/${settings.contact.facebook}`}
                  className="text-gray-400 hover:text-white transition"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <Facebook className="h-5 w-5" />
                </a>
              )}
              
              {settings.contact.instagram && (
                <a 
                  href={`https://instagram.com/${settings.contact.instagram}`}
                  className="text-gray-400 hover:text-white transition"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <Instagram className="h-5 w-5" />
                </a>
              )}
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

function formatCategory(category: string, isRtl: boolean): string {
  if (isRtl) {
    switch (category) {
      case 'main':
        return 'الأطباق الرئيسية';
      case 'appetizers':
        return 'المقبلات';
      case 'drinks':
        return 'المشروبات';
      case 'desserts':
        return 'الحلويات';
      case 'entrees':
        return 'المقبلات الرئيسية';
      case 'soups':
        return 'الشوربات';
      case 'coffee':
        return 'القهوة والشاي';
      case 'pizza':
        return 'البيتزا';
      default:
        return category;
    }
  } else {
    switch (category) {
      case 'main':
        return 'Main Dishes';
      case 'appetizers':
        return 'Appetizers';
      case 'drinks':
        return 'Drinks';
      case 'desserts':
        return 'Desserts';
      case 'entrees':
        return 'Entrées';
      case 'soups':
        return 'Soups';
      case 'coffee':
        return 'Coffee & Tea';
      case 'pizza':
        return 'Pizza';
      default:
        return category.charAt(0).toUpperCase() + category.slice(1);
    }
  }
}

function LoadingSkeleton() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header Skeleton */}
      <div className="bg-primary-700 shadow-sm">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center mb-4 md:mb-0">
              <Skeleton className="h-14 w-14 rounded-full" />
              <div className="ml-3">
                <Skeleton className="h-8 w-48" />
                <Skeleton className="h-4 w-32 mt-2" />
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Skeleton className="h-6 w-6 rounded-full" />
              <Skeleton className="h-6 w-6 rounded-full" />
              <Skeleton className="h-6 w-6 rounded-full" />
            </div>
          </div>
        </div>
      </div>
      
      {/* Categories Skeleton */}
      <div className="sticky top-0 z-10 bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center space-x-2 overflow-x-auto">
            <Skeleton className="h-10 w-24 rounded-full" />
            <Skeleton className="h-10 w-28 rounded-full" />
            <Skeleton className="h-10 w-20 rounded-full" />
            <Skeleton className="h-10 w-24 rounded-full" />
          </div>
        </div>
      </div>
      
      {/* Menu Items Skeleton */}
      <main className="container mx-auto px-4 py-8">
        <section className="mb-12">
          <Skeleton className="h-8 w-48 mb-6" />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="bg-white rounded-lg shadow-sm overflow-hidden">
                <Skeleton className="h-48 w-full" />
                <div className="p-4">
                  <div className="flex justify-between items-start">
                    <Skeleton className="h-6 w-32" />
                    <Skeleton className="h-6 w-16" />
                  </div>
                  <Skeleton className="h-4 w-full mt-2" />
                  <Skeleton className="h-4 w-3/4 mt-1" />
                </div>
              </div>
            ))}
          </div>
        </section>
      </main>
      
      {/* Footer Skeleton */}
      <div className="bg-gray-800 py-8">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <Skeleton className="h-6 w-32 mb-4 bg-gray-700" />
              <Skeleton className="h-4 w-full bg-gray-700" />
              <Skeleton className="h-4 w-3/4 mt-1 bg-gray-700" />
            </div>
            <div>
              <Skeleton className="h-6 w-24 mb-4 bg-gray-700" />
              <Skeleton className="h-4 w-full bg-gray-700" />
              <Skeleton className="h-4 w-3/4 mt-1 bg-gray-700" />
            </div>
            <div>
              <Skeleton className="h-6 w-20 mb-4 bg-gray-700" />
              <Skeleton className="h-4 w-full bg-gray-700" />
              <Skeleton className="h-4 w-3/4 mt-1 bg-gray-700" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
