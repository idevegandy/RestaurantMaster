import { useQuery } from "@tanstack/react-query";
import SuperAdminLayout from "@/components/layout/super-admin-layout";
import { Card, CardContent } from "@/components/ui/card";
import { Book, Users, Eye } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function SuperAdminDashboard() {
  const { data, isLoading } = useQuery({
    queryKey: ['/api/admin/restaurants']
  });
  
  const restaurants = data?.restaurants || [];
  
  // Calculate stats
  const totalRestaurants = restaurants.length;
  const totalAdmins = restaurants.filter(r => r.owner).length;
  const totalMenuItems = restaurants.reduce((sum, r) => sum + r.menuItemsCount, 0);
  
  return (
    <SuperAdminLayout title="Dashboard">
      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <StatsCard
          icon={<Book className="h-8 w-8" />}
          title="Total Restaurants"
          value={isLoading ? <Skeleton className="h-8 w-16" /> : totalRestaurants}
          iconBg="bg-blue-100"
          iconColor="text-blue-600"
        />
        
        <StatsCard
          icon={<Users className="h-8 w-8" />}
          title="Total Admins"
          value={isLoading ? <Skeleton className="h-8 w-16" /> : totalAdmins}
          iconBg="bg-green-100"
          iconColor="text-green-600"
        />
        
        <StatsCard
          icon={<Eye className="h-8 w-8" />}
          title="Menu Items"
          value={isLoading ? <Skeleton className="h-8 w-16" /> : totalMenuItems}
          iconBg="bg-purple-100"
          iconColor="text-purple-600"
        />
      </div>
      
      {/* Restaurants Overview */}
      <Card>
        <CardContent className="p-6">
          <h2 className="text-lg font-semibold text-gray-800 mb-6">Recent Restaurants</h2>
          
          {isLoading ? (
            <div className="space-y-4">
              {[1, 2, 3].map(i => (
                <div key={i} className="flex justify-between items-center p-4 border-b">
                  <div className="flex items-center">
                    <Skeleton className="h-10 w-10 rounded-full" />
                    <div className="ml-4">
                      <Skeleton className="h-5 w-36" />
                      <Skeleton className="h-4 w-24 mt-1" />
                    </div>
                  </div>
                  <Skeleton className="h-8 w-20" />
                </div>
              ))}
            </div>
          ) : (
            <div className="divide-y">
              {restaurants.slice(0, 5).map((restaurant) => (
                <div key={restaurant.id} className="flex justify-between items-center p-4">
                  <div className="flex items-center">
                    <div className="h-10 w-10 bg-gray-200 rounded-full flex items-center justify-center">
                      <span className="text-gray-600 font-medium">
                        {restaurant.name.charAt(0)}
                      </span>
                    </div>
                    <div className="ml-4">
                      <h3 className="font-medium">{restaurant.name}</h3>
                      <p className="text-sm text-gray-500">{restaurant.slug}</p>
                    </div>
                  </div>
                  <div className="text-sm">
                    <span className="text-gray-600">{restaurant.menuItemsCount} menu items</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </SuperAdminLayout>
  );
}

interface StatsCardProps {
  icon: React.ReactNode;
  title: string;
  value: React.ReactNode;
  iconBg: string;
  iconColor: string;
}

function StatsCard({ icon, title, value, iconBg, iconColor }: StatsCardProps) {
  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center">
          <div className={`p-3 rounded-full ${iconBg} ${iconColor} mr-4`}>
            {icon}
          </div>
          <div>
            <p className="text-sm font-medium text-gray-600">{title}</p>
            <p className="text-2xl font-bold text-gray-900">{value}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
