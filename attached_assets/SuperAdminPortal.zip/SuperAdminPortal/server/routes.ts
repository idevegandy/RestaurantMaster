import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { insertUserSchema, insertRestaurantSchema, insertMenuItemSchema, UserRole } from "@shared/schema";
import session from "express-session";
import MemoryStore from "memorystore";

// Extend express-session with our custom user property
declare module 'express-session' {
  interface SessionData {
    user?: {
      id: number;
      username: string;
      role: UserRole;
      restaurantId?: number | null;
    };
  }
}

// Helper function to handle errors
const handleError = (res: Response, error: any) => {
  console.error("Error:", error);
  res.status(500).json({
    success: false,
    message: error.message || "Internal server error",
  });
};

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // Configure session
  const MemoryStoreSession = MemoryStore(session);
  app.use(
    session({
      cookie: { maxAge: 86400000 }, // 24 hours
      store: new MemoryStoreSession({
        checkPeriod: 86400000, // prune expired entries every 24h
      }),
      resave: false,
      saveUninitialized: false,
      secret: process.env.SESSION_SECRET || "digital-menu-secret",
    })
  );

  // Authentication middleware
  const requireAuth = (req: Request, res: Response, next: NextFunction) => {
    if (!req.session.user) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    next();
  };

  // Role-based authorization middleware
  // Note: super_admin role has access to all endpoints
  const requireRole = (role: UserRole) => (req: Request, res: Response, next: NextFunction) => {
    if (!req.session.user) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    // Super admin can access everything
    if (req.session.user.role === 'super_admin') {
      return next();
    }
    
    // For other roles, they must match exactly
    if (req.session.user.role !== role) {
      return res.status(403).json({ message: "Access denied" });
    }
    
    next();
  };

  // ----- Auth Routes -----
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
      }

      const user = await storage.getUserByUsername(username);
      
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      // For development purposes, allowing plain text comparison
      // In production, this should be replaced with a proper password hash comparison
      // For simplicity in development, we're doing a direct comparison
      // In production, this should use a secure password comparison method
      if (user.password !== password) {
        console.log("Password mismatch", { provided: password, stored: user.password });
        return res.status(401).json({ message: "Invalid credentials" });
      }

      // Save user in session
      req.session.user = {
        id: user.id,
        username: user.username,
        role: user.role as UserRole,
        restaurantId: user.restaurantId,
      };

      res.json({
        success: true,
        user: {
          id: user.id,
          username: user.username,
          role: user.role,
          restaurantId: user.restaurantId,
        },
      });
    } catch (error) {
      handleError(res, error);
    }
  });

  app.get("/api/auth/me", (req, res) => {
    if (req.session.user) {
      res.json({ user: req.session.user });
    } else {
      res.status(401).json({ message: "Not authenticated" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return handleError(res, err);
      }
      res.json({ success: true });
    });
  });

  // ----- Super Admin Routes -----
  // Get all restaurants
  app.get("/api/admin/restaurants", requireRole('super_admin'), async (req, res) => {
    try {
      const restaurants = await storage.getAllRestaurants();
      
      // For each restaurant, add owner and menu items count
      const results = await Promise.all(restaurants.map(async (restaurant) => {
        const users = await storage.getAllUsers();
        const owner = users.find(u => u.restaurantId === restaurant.id && u.role === 'restaurant_admin');
        const menuItems = await storage.getMenuItemsByRestaurant(restaurant.id);
        
        return {
          ...restaurant,
          owner: owner ? { 
            id: owner.id, 
            username: owner.username 
          } : null,
          menuItemsCount: menuItems.length
        };
      }));
      
      res.json({ restaurants: results });
    } catch (error) {
      handleError(res, error);
    }
  });

  // Create restaurant
  app.post("/api/admin/restaurants", requireRole('super_admin'), async (req, res) => {
    try {
      const restaurantData = insertRestaurantSchema.parse(req.body);
      const restaurant = await storage.createRestaurant(restaurantData);
      res.status(201).json({ restaurant });
    } catch (error) {
      handleError(res, error);
    }
  });

  // Create restaurant owner
  app.post("/api/admin/restaurant-owners", requireRole('super_admin'), async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      userData.role = 'restaurant_admin' as UserRole;
      
      const user = await storage.createUser(userData);
      res.status(201).json({ user: { 
        id: user.id, 
        username: user.username,
        role: user.role,
        restaurantId: user.restaurantId
      } });
    } catch (error) {
      handleError(res, error);
    }
  });

  // Delete restaurant
  app.delete("/api/admin/restaurants/:id", requireRole('super_admin'), async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteRestaurant(id);
      res.json({ success: true });
    } catch (error) {
      handleError(res, error);
    }
  });

  // Update restaurant
  app.patch("/api/admin/restaurants/:id", requireRole('super_admin'), async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const restaurantData = req.body;
      const restaurant = await storage.updateRestaurant(id, restaurantData);
      
      if (!restaurant) {
        return res.status(404).json({ message: "Restaurant not found" });
      }
      
      res.json({ restaurant });
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Get all users (for super admin)
  app.get("/api/admin/users", requireRole('super_admin'), async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      
      // Don't return passwords
      const sanitizedUsers = users.map(user => ({
        id: user.id,
        username: user.username,
        role: user.role,
        restaurantId: user.restaurantId
      }));
      
      res.json({ users: sanitizedUsers });
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Update user
  app.patch("/api/admin/users/:id", requireRole('super_admin'), async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const userData = req.body;
      
      // Ensure we're not updating a super admin's role
      const existingUser = await storage.getUser(id);
      if (existingUser?.role === 'super_admin' && userData.role && userData.role !== 'super_admin') {
        return res.status(403).json({ message: "Cannot change super admin role" });
      }
      
      const user = await storage.updateUser(id, userData);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json({ 
        user: {
          id: user.id,
          username: user.username,
          role: user.role,
          restaurantId: user.restaurantId
        }
      });
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Delete user
  app.delete("/api/admin/users/:id", requireRole('super_admin'), async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      // Prevent deleting super admin users
      const user = await storage.getUser(id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      if (user.role === 'super_admin') {
        return res.status(403).json({ message: "Cannot delete super admin user" });
      }
      
      await storage.deleteUser(id);
      res.json({ success: true });
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Reset user password
  app.post("/api/admin/users/:id/reset-password", requireRole('super_admin'), async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { password } = req.body;
      
      if (!password) {
        return res.status(400).json({ message: "Password is required" });
      }
      
      const user = await storage.updateUser(id, { password });
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json({ success: true });
    } catch (error) {
      handleError(res, error);
    }
  });

  // ----- Restaurant Admin Routes -----
  // Get restaurant details
  app.get("/api/restaurant", requireAuth, async (req, res) => {
    try {
      const restaurantId = req.session.user?.restaurantId;
      
      if (!restaurantId) {
        return res.status(400).json({ message: "No restaurant associated with this account" });
      }
      
      const restaurant = await storage.getRestaurant(restaurantId);
      
      if (!restaurant) {
        return res.status(404).json({ message: "Restaurant not found" });
      }
      
      res.json({ restaurant });
    } catch (error) {
      handleError(res, error);
    }
  });

  // Get menu items for a restaurant
  app.get("/api/restaurant/menu-items", requireAuth, async (req, res) => {
    try {
      const restaurantId = req.session.user?.restaurantId;
      
      if (!restaurantId) {
        return res.status(400).json({ message: "No restaurant associated with this account" });
      }
      
      const menuItems = await storage.getMenuItemsByRestaurant(restaurantId);
      res.json({ menuItems });
    } catch (error) {
      handleError(res, error);
    }
  });

  // Create menu item
  app.post("/api/restaurant/menu-items", requireAuth, async (req, res) => {
    try {
      const restaurantId = req.session.user?.restaurantId;
      
      if (!restaurantId) {
        return res.status(400).json({ message: "No restaurant associated with this account" });
      }
      
      const itemData = insertMenuItemSchema.parse(req.body);
      itemData.restaurantId = restaurantId;
      
      const menuItem = await storage.createMenuItem(itemData);
      res.status(201).json({ menuItem });
    } catch (error) {
      handleError(res, error);
    }
  });

  // Update menu item
  app.patch("/api/restaurant/menu-items/:id", requireAuth, async (req, res) => {
    try {
      const restaurantId = req.session.user?.restaurantId;
      const itemId = parseInt(req.params.id);
      
      if (!restaurantId) {
        return res.status(400).json({ message: "No restaurant associated with this account" });
      }
      
      // Verify this menu item belongs to the restaurant
      const menuItem = await storage.getMenuItem(itemId);
      
      if (!menuItem) {
        return res.status(404).json({ message: "Menu item not found" });
      }
      
      if (menuItem.restaurantId !== restaurantId) {
        return res.status(403).json({ message: "You don't have permission to update this menu item" });
      }
      
      const updatedItem = await storage.updateMenuItem(itemId, req.body);
      res.json({ menuItem: updatedItem });
    } catch (error) {
      handleError(res, error);
    }
  });

  // Delete menu item
  app.delete("/api/restaurant/menu-items/:id", requireAuth, async (req, res) => {
    try {
      const restaurantId = req.session.user?.restaurantId;
      const itemId = parseInt(req.params.id);
      
      if (!restaurantId) {
        return res.status(400).json({ message: "No restaurant associated with this account" });
      }
      
      // Verify this menu item belongs to the restaurant
      const menuItem = await storage.getMenuItem(itemId);
      
      if (!menuItem) {
        return res.status(404).json({ message: "Menu item not found" });
      }
      
      if (menuItem.restaurantId !== restaurantId) {
        return res.status(403).json({ message: "You don't have permission to delete this menu item" });
      }
      
      await storage.deleteMenuItem(itemId);
      res.json({ success: true });
    } catch (error) {
      handleError(res, error);
    }
  });

  // Update restaurant settings (branding)
  app.patch("/api/restaurant/settings", requireAuth, async (req, res) => {
    try {
      const restaurantId = req.session.user?.restaurantId;
      
      if (!restaurantId) {
        return res.status(400).json({ message: "No restaurant associated with this account" });
      }
      
      const restaurant = await storage.getRestaurant(restaurantId);
      
      if (!restaurant) {
        return res.status(404).json({ message: "Restaurant not found" });
      }
      
      const updatedRestaurant = await storage.updateRestaurant(restaurantId, {
        settings: {
          ...restaurant.settings,
          ...req.body
        }
      });
      
      res.json({ restaurant: updatedRestaurant });
    } catch (error) {
      handleError(res, error);
    }
  });

  // ----- Public Routes -----
  // Get public restaurant menu by slug
  app.get("/api/public/menu/:slug", async (req, res) => {
    try {
      const { slug } = req.params;
      const restaurant = await storage.getRestaurantBySlug(slug);
      
      if (!restaurant) {
        return res.status(404).json({ message: "Restaurant not found" });
      }
      
      const menuItems = await storage.getMenuItemsByRestaurant(restaurant.id);
      
      res.json({
        restaurant: {
          id: restaurant.id,
          name: restaurant.name,
          slug: restaurant.slug,
          settings: restaurant.settings
        },
        menuItems
      });
    } catch (error) {
      handleError(res, error);
    }
  });

  return httpServer;
}
