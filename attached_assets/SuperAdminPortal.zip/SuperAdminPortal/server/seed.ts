import { db } from './db';
import { users, restaurants, menuItems } from '@shared/schema';
import { eq } from 'drizzle-orm';

// Seed function to populate the database with initial data
async function seedDatabase() {
  console.log('Seeding database...');

  // Clear existing data first
  try {
    await db.delete(menuItems);
    await db.delete(users);
    await db.delete(restaurants);
    console.log('Cleared existing data');
  } catch (error) {
    console.error('Error clearing existing data:', error);
    return;
  }

  // Insert super admin user
  try {
    const [superAdmin] = await db.insert(users).values({
      username: 'admin',
      password: 'admin123', // In a real app, this would be hashed
      role: 'super_admin',
      restaurantId: null
    }).returning();
    
    console.log('Created super admin user');

    // Insert a restaurant
    const [restaurant] = await db.insert(restaurants).values({
      name: 'Arabian Nights',
      slug: 'arabian-nights',
      settings: {
        primaryColor: '#4f46e5',
        secondaryColor: '#10b981',
        contact: {
          email: 'contact@arabiannights.com',
          phone: '+966501234567',
          facebook: 'arabiannights',
          instagram: 'arabiannights',
          hours: {
            weekdays: 'Monday - Thursday: 11:00 AM - 10:00 PM',
            weekend: 'Friday - Sunday: 11:00 AM - 11:00 PM'
          }
        }
      }
    }).returning();
    
    console.log('Created restaurant:', restaurant.name);

    // Insert a restaurant admin
    await db.insert(users).values({
      username: 'owner1',
      password: 'pass1', // In a real app, this would be hashed
      role: 'restaurant_admin',
      restaurantId: restaurant.id
    });
    
    console.log('Created restaurant admin user');

    // Insert menu items
    await db.insert(menuItems).values([
      {
        name: 'Mandi Chicken',
        price: '35 SAR',
        description: 'Traditional Yemeni dish with fragrant rice',
        category: 'main',
        image: '',
        restaurantId: restaurant.id
      },
      {
        name: 'Karak Tea',
        price: '8 SAR',
        description: 'Creamy Qatari-style tea',
        category: 'drinks',
        image: '',
        restaurantId: restaurant.id
      },
      {
        name: 'Baklava',
        price: '25 SAR',
        description: 'Sweet pastry made of layers of filo filled with chopped nuts and sweetened with honey.',
        category: 'desserts',
        image: 'https://images.unsplash.com/photo-1625517236222-9def1fca40a5?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTJ8fGJha2xhdmF8ZW58MHx8MHx8fDA%3D',
        restaurantId: restaurant.id
      },
      {
        name: 'Hummus',
        price: '20 SAR',
        description: 'Creamy chickpea dip with tahini, lemon juice, and olive oil. Served with fresh pita bread.',
        category: 'appetizers',
        image: 'https://images.unsplash.com/photo-1577805947697-89e18249d767?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8aHVtbXVzfGVufDB8fDB8fHww',
        restaurantId: restaurant.id
      }
    ]);
    
    console.log('Created menu items');

    console.log('Database seeded successfully!');
  } catch (error) {
    console.error('Error seeding database:', error);
  }
}

// Run the seed function
seedDatabase().then(() => {
  console.log('Seed script completed');
  process.exit(0);
}).catch(error => {
  console.error('Seed script failed:', error);
  process.exit(1);
});