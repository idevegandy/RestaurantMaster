import { 
  User, InsertUser, 
  Restaurant, InsertRestaurant, 
  MenuItem, InsertMenuItem,
  RestaurantSettings,
  users, restaurants, menuItems
} from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllUsers(): Promise<User[]>;
  updateUser(id: number, data: Partial<InsertUser>): Promise<User | undefined>;
  deleteUser(id: number): Promise<boolean>;

  // Restaurant operations
  getRestaurant(id: number): Promise<Restaurant | undefined>;
  getRestaurantBySlug(slug: string): Promise<Restaurant | undefined>;
  createRestaurant(restaurant: InsertRestaurant): Promise<Restaurant>;
  updateRestaurant(id: number, data: Partial<InsertRestaurant>): Promise<Restaurant | undefined>;
  deleteRestaurant(id: number): Promise<boolean>;
  getAllRestaurants(): Promise<Restaurant[]>;

  // Menu items operations
  getMenuItem(id: number): Promise<MenuItem | undefined>;
  getMenuItemsByRestaurant(restaurantId: number): Promise<MenuItem[]>;
  createMenuItem(item: InsertMenuItem): Promise<MenuItem>;
  updateMenuItem(id: number, data: Partial<InsertMenuItem>): Promise<MenuItem | undefined>;
  deleteMenuItem(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private restaurants: Map<number, Restaurant>;
  private menuItems: Map<number, MenuItem>;

  private userId: number;
  private restaurantId: number;
  private menuItemId: number;

  constructor() {
    this.users = new Map();
    this.restaurants = new Map();
    this.menuItems = new Map();

    this.userId = 1;
    this.restaurantId = 1;
    this.menuItemId = 1;

    // Initialize with some sample data
    this.seedData();
  }

  private seedData() {
    // Add super admin
    this.users.set(this.userId++, {
      id: 1,
      username: 'admin',
      password: 'admin123',
      role: 'super_admin',
      restaurantId: null
    });

    // Add a sample restaurant
    const restaurantId = this.restaurantId++;
    const restaurantSettings: RestaurantSettings = {
      primaryColor: '#4f46e5',
      secondaryColor: '#10b981',
      contact: {
        email: 'contact@arabiannights.com',
        phone: '+966501234567',
        facebook: 'arabiannights',
        instagram: 'arabiannights',
        hours: {
          weekdays: 'Monday - Thursday: 11:00 AM - 10:00 PM',
          weekend: 'Friday - Sunday: 11:00 AM - 11:00 PM'
        }
      }
    };

    this.restaurants.set(restaurantId, {
      id: restaurantId,
      name: 'Arabian Nights',
      slug: 'arabian-nights',
      settings: restaurantSettings
    });

    // Add a restaurant admin
    this.users.set(this.userId++, {
      id: 2,
      username: 'owner1',
      password: 'pass1',
      role: 'restaurant_admin',
      restaurantId: restaurantId
    });

    // Add menu items
    this.menuItems.set(this.menuItemId++, {
      id: 1,
      name: 'Mandi Chicken',
      price: '35 SAR',
      description: 'Traditional Yemeni dish with fragrant rice',
      category: 'main',
      image: '',
      restaurantId: restaurantId
    });

    this.menuItems.set(this.menuItemId++, {
      id: 2,
      name: 'Karak Tea',
      price: '8 SAR',
      description: 'Creamy Qatari-style tea',
      category: 'drinks',
      image: '',
      restaurantId: restaurantId
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(userData: InsertUser): Promise<User> {
    const id = this.userId++;
    const user: User = { id, ...userData };
    this.users.set(id, user);
    return user;
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  async updateUser(id: number, data: Partial<InsertUser>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;

    const updatedUser = { ...user, ...data };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async deleteUser(id: number): Promise<boolean> {
    return this.users.delete(id);
  }

  // Restaurant methods
  async getRestaurant(id: number): Promise<Restaurant | undefined> {
    return this.restaurants.get(id);
  }

  async getRestaurantBySlug(slug: string): Promise<Restaurant | undefined> {
    return Array.from(this.restaurants.values()).find(
      (restaurant) => restaurant.slug === slug
    );
  }

  async createRestaurant(restaurantData: InsertRestaurant): Promise<Restaurant> {
    const id = this.restaurantId++;
    const restaurant: Restaurant = { id, ...restaurantData };
    this.restaurants.set(id, restaurant);
    return restaurant;
  }

  async updateRestaurant(id: number, data: Partial<InsertRestaurant>): Promise<Restaurant | undefined> {
    const restaurant = this.restaurants.get(id);
    if (!restaurant) return undefined;

    // For settings, merge them instead of replacing
    if (data.settings && restaurant.settings) {
      data.settings = { 
        ...restaurant.settings, 
        ...data.settings,
        contact: { ...restaurant.settings.contact, ...data.settings.contact }
      };
    }

    const updatedRestaurant = { ...restaurant, ...data };
    this.restaurants.set(id, updatedRestaurant);
    return updatedRestaurant;
  }

  async deleteRestaurant(id: number): Promise<boolean> {
    // Delete restaurant
    const deleted = this.restaurants.delete(id);
    
    // Delete associated menu items
    for (const [itemId, item] of this.menuItems.entries()) {
      if (item.restaurantId === id) {
        this.menuItems.delete(itemId);
      }
    }
    
    return deleted;
  }

  async getAllRestaurants(): Promise<Restaurant[]> {
    return Array.from(this.restaurants.values());
  }

  // Menu item methods
  async getMenuItem(id: number): Promise<MenuItem | undefined> {
    return this.menuItems.get(id);
  }

  async getMenuItemsByRestaurant(restaurantId: number): Promise<MenuItem[]> {
    return Array.from(this.menuItems.values()).filter(
      (item) => item.restaurantId === restaurantId
    );
  }

  async createMenuItem(itemData: InsertMenuItem): Promise<MenuItem> {
    const id = this.menuItemId++;
    const item: MenuItem = { id, ...itemData };
    this.menuItems.set(id, item);
    return item;
  }

  async updateMenuItem(id: number, data: Partial<InsertMenuItem>): Promise<MenuItem | undefined> {
    const item = this.menuItems.get(id);
    if (!item) return undefined;

    const updatedItem = { ...item, ...data };
    this.menuItems.set(id, updatedItem);
    return updatedItem;
  }

  async deleteMenuItem(id: number): Promise<boolean> {
    return this.menuItems.delete(id);
  }
}

export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(userData: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .returning();
    return user;
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  async updateUser(id: number, data: Partial<InsertUser>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set(data)
      .where(eq(users.id, id))
      .returning();
    return user || undefined;
  }

  async deleteUser(id: number): Promise<boolean> {
    const result = await db
      .delete(users)
      .where(eq(users.id, id));
    return true; // Assuming success if no error is thrown
  }

  // Restaurant methods
  async getRestaurant(id: number): Promise<Restaurant | undefined> {
    const [restaurant] = await db.select().from(restaurants).where(eq(restaurants.id, id));
    return restaurant || undefined;
  }

  async getRestaurantBySlug(slug: string): Promise<Restaurant | undefined> {
    const [restaurant] = await db.select().from(restaurants).where(eq(restaurants.slug, slug));
    return restaurant || undefined;
  }

  async createRestaurant(restaurantData: InsertRestaurant): Promise<Restaurant> {
    const [restaurant] = await db
      .insert(restaurants)
      .values(restaurantData)
      .returning();
    return restaurant;
  }

  async updateRestaurant(id: number, data: Partial<InsertRestaurant>): Promise<Restaurant | undefined> {
    // If updating settings, merge with existing settings
    if (data.settings) {
      const [existingRestaurant] = await db
        .select()
        .from(restaurants)
        .where(eq(restaurants.id, id));
      
      if (existingRestaurant) {
        data.settings = {
          ...existingRestaurant.settings,
          ...data.settings,
          contact: {
            ...existingRestaurant.settings.contact,
            ...(data.settings.contact || {})
          }
        };
      }
    }
    
    const [restaurant] = await db
      .update(restaurants)
      .set(data)
      .where(eq(restaurants.id, id))
      .returning();
    return restaurant || undefined;
  }

  async deleteRestaurant(id: number): Promise<boolean> {
    // First delete associated menu items
    await db
      .delete(menuItems)
      .where(eq(menuItems.restaurantId, id));
    
    // Delete associated users (except super admins)
    await db
      .delete(users)
      .where(eq(users.restaurantId, id));
    
    // Finally delete the restaurant
    await db
      .delete(restaurants)
      .where(eq(restaurants.id, id));
    
    return true; // Assuming success if no error is thrown
  }

  async getAllRestaurants(): Promise<Restaurant[]> {
    return await db.select().from(restaurants);
  }

  // Menu item methods
  async getMenuItem(id: number): Promise<MenuItem | undefined> {
    const [item] = await db.select().from(menuItems).where(eq(menuItems.id, id));
    return item || undefined;
  }

  async getMenuItemsByRestaurant(restaurantId: number): Promise<MenuItem[]> {
    return await db
      .select()
      .from(menuItems)
      .where(eq(menuItems.restaurantId, restaurantId));
  }

  async createMenuItem(itemData: InsertMenuItem): Promise<MenuItem> {
    const [item] = await db
      .insert(menuItems)
      .values(itemData)
      .returning();
    return item;
  }

  async updateMenuItem(id: number, data: Partial<InsertMenuItem>): Promise<MenuItem | undefined> {
    const [item] = await db
      .update(menuItems)
      .set(data)
      .where(eq(menuItems.id, id))
      .returning();
    return item || undefined;
  }

  async deleteMenuItem(id: number): Promise<boolean> {
    await db
      .delete(menuItems)
      .where(eq(menuItems.id, id));
    return true; // Assuming success if no error is thrown
  }
}

// Switch from MemStorage to DatabaseStorage
export const storage = new DatabaseStorage();
