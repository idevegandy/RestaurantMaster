import { pgTable, text, serial, integer, json, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema with role
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").notNull().default('restaurant_admin'),
  restaurantId: integer("restaurant_id"),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
});

// Restaurant schema
export const restaurants = pgTable("restaurants", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  settings: json("settings").$type<RestaurantSettings>().notNull(),
});

export const insertRestaurantSchema = createInsertSchema(restaurants).omit({
  id: true,
});

// Menu items schema
export const menuItems = pgTable("menu_items", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  price: text("price").notNull(),
  description: text("description"),
  category: text("category").notNull(),
  image: text("image"),
  restaurantId: integer("restaurant_id").notNull(),
});

export const insertMenuItemSchema = createInsertSchema(menuItems).omit({
  id: true,
});

// Type definitions
export type UserRole = 'super_admin' | 'restaurant_admin';

export interface RestaurantSettings {
  primaryColor: string;
  secondaryColor: string;
  logo?: string;
  textDirection?: 'ltr' | 'rtl';
  language?: 'en' | 'ar';
  contact: {
    email: string;
    phone: string;
    facebook?: string;
    instagram?: string;
    hours?: {
      weekdays: string;
      weekend: string;
    };
  };
}

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Restaurant = typeof restaurants.$inferSelect;
export type InsertRestaurant = z.infer<typeof insertRestaurantSchema>;

export type MenuItem = typeof menuItems.$inferSelect;
export type InsertMenuItem = z.infer<typeof insertMenuItemSchema>;
