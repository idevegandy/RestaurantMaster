#!/bin/bash

echo "Setting up database..."

# Run the database push to create tables
echo "Pushing schema to database..."
npx drizzle-kit push

# Run the seed script to populate the database
echo "Seeding database with initial data..."
npx tsx server/seed.ts

echo "Database setup completed!"